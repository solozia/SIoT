
# varying the number of vorequired in a CVO
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 5 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 10 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 15 10
      sleep 10

done      
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 20 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 25 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 30 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 35 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 40 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 45 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 1000 50 10
      sleep 10

done
sleep 1m

#Varying the candidate objects thatt is dataset

for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 10000 3 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 20000 3 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 30000 3 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 40000 3 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 50000 3 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 60000 3 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 70000 3 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 80000 3 10
      sleep 10

done
sleep 10
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 90000 3 10
      sleep 10

done
for (( i = 1 ; i <= 10 ; i++ ))  do
      java -jar IP.jar 100000 3 10
      
done

